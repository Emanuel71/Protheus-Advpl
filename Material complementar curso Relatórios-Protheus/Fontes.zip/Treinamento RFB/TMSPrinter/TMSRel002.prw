#INCLUDE "RWMAKE.CH"
#INCLUDE "PROTHEUS.CH"
#INCLUDE "topconn.ch"

USER FUNCTION TMSRel02()
	PRIVATE	cTitulo		:=	"Relat�rio de Livros"
	PRIVATE	cNomeProg	:=	FunName()
	PRIVATE	cPerg		:=	"TMSREL02"
	PRIVATE	oDlg		:=	NIL
	PRIVATE	oRelatorio	:=	NIL
	PRIVATE oFont1		:=	NIL
	PRIVATE oFont2		:=	NIL
	PRIVATE oFont3		:=	NIL
	PRIVATE oFont4		:=	NIL
	PRIVATE oFont5		:=	NIL
	PRIVATE oFont6		:=	NIL
	PRIVATE oFont7		:=	TFont():New("Arial",07,07,,.F.,,,,.T.,.F.)
	PRIVATE oFont8		:=	TFont():New("Arial",07,07,,.F.,,,,.T.,.F.)
	PRIVATE	oFont10		:=	TFont():New("Arial",8.5,8.5,,.F.,,,,.T.,.F.)
	PRIVATE	nPag		:=	0
	
	/*
	IF !Pergunte(cPerg, .T.)
		RETURN
	ENDIF
	*/
	
	DEFINE FONT oFont1 NAME "Tahoma"			SIZE 0,-15	BOLD	OF oRelatorio
	DEFINE FONT oFont2 NAME "Tahoma"			SIZE 0,-25	BOLD	OF oRelatorio
	DEFINE FONT oFont3 NAME "Times New Roman"	SIZE 0,12			OF oRelatorio
	DEFINE FONT oFont4 NAME "Times New Roman"	SIZE 0,10	ITALIC	OF oRelatorio
	DEFINE FONT oFont5 NAME "Times New Roman"	SIZE 0,08			OF oRelatorio
	DEFINE FONT oFont6 NAME "Courier New" BOLD
	
	/*
		Fontes homologadas para uso:
			* Courier New
			* Arial
			* Times New Roman
			* Helvetica
			* Microsoft Sans Serif
			* Verdana
			* Tahoma
			* Andalus
			* Century
			* Cordia New
	*/
		
	oRelatorio	:=	TMSPrinter():New(cTitulo)
	oRelatorio:Setup()
	oRelatorio:SetLandscape()//SetPortrait() //SetLansCape()
	oRelatorio:SetPaperSize(DMPAPER_A4)
	oRelatorio:StartPage()
	Imprimir()
	Ms_Flush()
	oRelatorio:EndPage()
	oRelatorio:End()
	
	DEFINE MSDIALOG oDlg FROM 264,182 TO 441,613 TITLE cTitulo OF oDlg PIXEL
		@ 004,010 TO 082,157 LABEL "" OF oDlg PIXEL
		 
		@ 015,017 SAY "Esta rotina tem por objetivo imprimir"	OF oDlg PIXEL Size 150,010 FONT oFont6 COLOR CLR_HBLUE
		@ 030,017 SAY "o relat�rio customizado:"				OF oDlg PIXEL Size 150,010 FONT oFont6 COLOR CLR_HBLUE
		@ 045,017 SAY cTitulo 									OF oDlg PIXEL Size 150,010 FONT oFont6 COLOR CLR_HBLUE
		 
		@ 06,167 BUTTON "&Imprime" 		SIZE 036,012 ACTION oRelatorio:Print()   	OF oDlg PIXEL
		@ 28,167 BUTTON "&Preview" 		SIZE 036,012 ACTION oRelatorio:Preview() 	OF oDlg PIXEL
		@ 49,167 BUTTON "&Sair"    		SIZE 036,012 ACTION oDlg:End()     			OF oDlg PIXEL
		 
	ACTIVATE MSDIALOG oDlg CENTERED
RETURN

STATIC FUNCTION Imprimir()
	LOCAL	nLin		:=	9999
	LOCAL	nPosCodigo	:=	0100
	LOCAL	nPosTitulo	:=	0500
	LOCAL	nPosAutor	:=	0850
	LOCAL	nPosEditor	:=	1300
	LOCAL	nPosEdicao	:=	1800
	LOCAL	nPosAno		:=	2250
	
	SZ4->( DBSETORDER(1) )
	SZ4->( DBGOTOP() )
	
	WHILE !SZ4->( EOF() )
		IF nLin >= oRelatorio:nVertRes()
			IF nLin	!=	9999
				oRelatorio:EndPage()
			ENDIF
			
			// Imprime cabe�alho
			CabecRel()
			
			nLin	:=	0200
			oRelatorio:Say(nLin,nPosCodigo,	UPPER("C�digo"),	oFont1)
			oRelatorio:Say(nLin,nPosTitulo,	UPPER("T�tulo"),	oFont1)
			oRelatorio:Say(nLin,nPosAutor,	UPPER("Autor"),		oFont1)
			oRelatorio:Say(nLin,nPosEditor,	UPPER("Editora"),	oFont1)
			oRelatorio:Say(nLin,nPosEdicao,	UPPER("Edi��o"),	oFont1)
			oRelatorio:Say(nLin,nPosAno,	UPPER("Ano"),		oFont1)
			
			oRelatorio:Line(nLin,nPosCodigo - 50,oRelatorio:nVertRes() - 100,nPosCodigo - 50 )
			oRelatorio:Line(nLin,nPosTitulo - 50,oRelatorio:nVertRes() - 100,nPosTitulo - 50 )
			oRelatorio:Line(nLin,nPosAutor - 50,oRelatorio:nVertRes() - 100,nPosAutor - 50 )
			oRelatorio:Line(nLin,nPosEditor - 50,oRelatorio:nVertRes() - 100,nPosEditor - 50 )
			oRelatorio:Line(nLin,nPosEdicao - 50,oRelatorio:nVertRes() - 100,nPosEdicao - 50 )
			oRelatorio:Line(nLin,nPosAno - 50,oRelatorio:nVertRes() - 100,nPosAno - 50 )
			
			nLin	+=	55
			oRelatorio:Line(nLin,0010,nLin,oRelatorio:nHorzRes() )
			
			nLin	+=	35
		ENDIF
		
		oRelatorio:Say(nLin,nPosCodigo,	SZ4->Z4_CODIGO, oFont5)
		oRelatorio:Say(nLin,nPosTitulo,	SZ4->Z4_TITULO, oFont5)
		oRelatorio:Say(nLin,nPosAutor,	POSICIONE('SZ2',1,SZ4->Z4_AUTOR,'Z2_NOME'), oFont5)
		oRelatorio:Say(nLin,nPosEditor,	POSICIONE('SZ3',1,SZ4->Z4_EDITORA,'Z3_NOME'), oFont5)
		oRelatorio:Say(nLin,nPosEdicao,	SZ4->Z4_EDICAO, oFont5)
		oRelatorio:Say(nLin,nPosAno,	cValToChar(SZ4->Z4_ANO), oFont5)
		
		nLin	+=	45
		
		SZ4->( DBSKIP() )
	ENDDO
	
	
	
	oRelatorio:EndPage()
RETURN

STATIC FUNCTION CabecRel()
	LOCAL	nHorzRes	:=	oRelatorio:nHorzRes()
	
	nPag++
	
	oRelatorio:StartPage()
	oRelatorio:Box(020,020,150,nHorzRes - 080)
	oRelatorio:Say(025,040,'RELAT�RIO : TMSREL02',oFont8)
	oRelatorio:Say(055,040,'EMISS�O : ' + DTOC(dDataBase),oFont8)
	oRelatorio:Say(085,040,'IMPRESSORA : ' + oRelatorio:PrinterName() ,oFont8)
	
	oRelatorio:Say(035,1200,UPPER(cTitulo),oFont2)
	
	oRelatorio:Say(025,nHorzRes - 400,'EMPRESA: ' + SM0->M0_CODIGO + ' - ' + SM0->M0_NOME,oFont8)
	oRelatorio:Say(055,nHorzRes - 400,'FILIAL:  ' + SM0->M0_CODFIL + ' - ' + SM0->M0_FILIAL,oFont8)
	oRelatorio:Say(085,nHorzRes - 400,'P�GINA:  ' + cValToChar(nPag),oFont8)
	
	oRelatorio:SayBitmap( 025,nHorzRes - 800,"\system\RFBLOGO.bmp",350,120 )
RETURN