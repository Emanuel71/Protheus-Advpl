#INCLUDE "RWMAKE.CH"
#INCLUDE "PROTHEUS.CH"
#INCLUDE "topconn.ch"

// Tamanho de folhas poss�veis para o m�todo tmsprinter:setPaperSize()
#DEFINE DMPAPER_LETTER 1				// Letter 8 1/2 x 11 in
#DEFINE DMPAPER_LETTERSMALL 2			// Letter Small 8 1/2 x 11 in
#DEFINE DMPAPER_TABLOID 3				// Tabloid 11 x 17 in
#DEFINE DMPAPER_LEDGER 4				// Ledger 17 x 11 in
#DEFINE DMPAPER_LEGAL 5					// Legal 8 1/2 x 14 in
#DEFINE DMPAPER_STATEMENT 6				// Statement 5 1/2 x 8 1/2 in
#DEFINE DMPAPER_EXECUTIVE 7				// Executive 7 1/4 x 10 1/2 in
#DEFINE DMPAPER_A3 8					// A3 297 x 420 mm
#DEFINE DMPAPER_A4 9					// A4 210 x 297 mm
#DEFINE DMPAPER_A4SMALL 10				// A4 Small 210 x 297 mm
#DEFINE DMPAPER_A5 11					// A5 148 x 210 mm
#DEFINE DMPAPER_B4 12					// B4 250 x 354
#DEFINE DMPAPER_B5 13					// B5 182 x 257 mm
#DEFINE DMPAPER_FOLIO 14				// Folio 8 1/2 x 13 in
#DEFINE DMPAPER_QUARTO 15				// Quarto 215 x 275 mm
#DEFINE DMPAPER_10X14 16				// 10x14 in
#DEFINE DMPAPER_11X17 17				// 11x17 in
#DEFINE DMPAPER_NOTE 18					// Note 8 1/2 x 11 in
#DEFINE DMPAPER_ENV_9 19				// Envelope #9 3 7/8 x 8 7/8
#DEFINE DMPAPER_ENV_10 20				// Envelope #10 4 1/8 x 9 1/2
#DEFINE DMPAPER_ENV_11 21				// Envelope #11 4 1/2 x 10 3/8
#DEFINE DMPAPER_ENV_12 22				// Envelope #12 4 \276 x 11
#DEFINE DMPAPER_ENV_14 23				// Envelope #14 5 x 11 1/2
#DEFINE DMPAPER_CSHEET 24				// C size sheet
#DEFINE DMPAPER_DSHEET 25				// D size sheet
#DEFINE DMPAPER_ESHEET 26				// E size sheet
#DEFINE DMPAPER_ENV_DL 27				// Envelope DL 110 x 220mm
#DEFINE DMPAPER_ENV_C5 28				// Envelope C5 162 x 229 mm
#DEFINE DMPAPER_ENV_C3 29				// Envelope C3 324 x 458 mm
#DEFINE DMPAPER_ENV_C4 30				// Envelope C4 229 x 324 mm
#DEFINE DMPAPER_ENV_C6 31				// Envelope C6 114 x 162 mm
#DEFINE DMPAPER_ENV_C65 32				// Envelope C65 114 x 229 mm
#DEFINE DMPAPER_ENV_B4 33				// Envelope B4 250 x 353 mm
#DEFINE DMPAPER_ENV_B5 34				// Envelope B5 176 x 250 mm
#DEFINE DMPAPER_ENV_B6 35				// Envelope B6 176 x 125 mm
#DEFINE DMPAPER_ENV_ITALY 36			// Envelope 110 x 230 mm
#DEFINE DMPAPER_ENV_MONARCH 37			// Envelope Monarch 3.875 x 7.5 in
#DEFINE DMPAPER_ENV_PERSONAL 38			// 6 3/4 Envelope 3 5/8 x 6 1/2 in
#DEFINE DMPAPER_FANFOLD_US 39			// US Std Fanfold 14 7/8 x 11 in
#DEFINE DMPAPER_FANFOLD_STD_GERMAN 40	// German Std Fanfold 8 1/2 x 12 in
#DEFINE DMPAPER_FANFOLD_LGL_GERMAN 41	// German Legal Fanfold 8 1/2 x 13 in

/*/{Protheus.doc} TMSRel001
Relat�rio de Autores
@author Klaus W Kuhl Breit
@since 09/2018
@version 1.0
@type function
/*/
USER FUNCTION TMSRel01()
	PRIVATE	cTitulo		:=	"Relat�rio de Autores"
	PRIVATE	cNomeProg	:=	FunName()
	PRIVATE	cPerg		:=	"TMSREL01"
	PRIVATE	oDlg		:=	NIL
	PRIVATE	oRelatorio	:=	NIL
	PRIVATE oFont1		:=	NIL
	PRIVATE oFont2		:=	NIL
	PRIVATE oFont3		:=	NIL
	PRIVATE oFont4		:=	NIL
	PRIVATE oFont5		:=	NIL
	PRIVATE oFont6		:=	NIL
	
	/*
	IF !Pergunte(cPerg, .T.)
		RETURN
	ENDIF
	*/
	
	DEFINE FONT oFont1 NAME "Times New Roman"	SIZE 0,20	BOLD	OF oRelatorio
	DEFINE FONT oFont2 NAME "Tahoma"			SIZE 0,-25	BOLD	OF oRelatorio
	DEFINE FONT oFont3 NAME "Times New Roman"	SIZE 0,12			OF oRelatorio
	DEFINE FONT oFont4 NAME "Times New Roman"	SIZE 0,10	ITALIC	OF oRelatorio
	DEFINE FONT oFont5 NAME "Times New Roman"	SIZE 0,08			OF oRelatorio
	DEFINE FONT oFont6 NAME "Courier New" BOLD
	
	/*
		Fontes homologadas para uso:
			* Courier New
			* Arial
			* Times New Roman
			* Helvetica
			* Microsoft Sans Serif
			* Verdana
			* Tahoma
			* Andalus
			* Century
			* Cordia New
	*/
		
	oRelatorio	:=	TMSPrinter():New(cTitulo)
	oRelatorio:Setup()
	oRelatorio:SetLandscape()//SetPortrait() //SetLansCape()
	oRelatorio:SetPaperSize(DMPAPER_A4)
	oRelatorio:StartPage()
	Imprimir()
	Ms_Flush()
	oRelatorio:EndPage()
	oRelatorio:End()
	
	DEFINE MSDIALOG oDlg FROM 264,182 TO 441,613 TITLE cTitulo OF oDlg PIXEL
		@ 004,010 TO 082,157 LABEL "" OF oDlg PIXEL
		 
		@ 015,017 SAY "Esta rotina tem por objetivo imprimir"	OF oDlg PIXEL Size 150,010 FONT oFont6 COLOR CLR_HBLUE
		@ 030,017 SAY "o relat�rio customizado:"				OF oDlg PIXEL Size 150,010 FONT oFont6 COLOR CLR_HBLUE
		@ 045,017 SAY cTitulo 									OF oDlg PIXEL Size 150,010 FONT oFont6 COLOR CLR_HBLUE
		 
		@ 06,167 BUTTON "&Imprime" 		SIZE 036,012 ACTION oRelatorio:Print()   	OF oDlg PIXEL
		@ 28,167 BUTTON "&Preview" 		SIZE 036,012 ACTION oRelatorio:Preview() 	OF oDlg PIXEL
		@ 49,167 BUTTON "&Sair"    		SIZE 036,012 ACTION oDlg:End()     			OF oDlg PIXEL
		 
	ACTIVATE MSDIALOG oDlg CENTERED
	
RETURN

STATIC FUNCTION Imprimir()
	LOCAL	nLin		:=	9999
	LOCAL	nPosCodigo	:=	0100
	LOCAL	nPosTipo	:=	0350
	LOCAL	nPosNome	:=	0750
		
	SZ2->( DBSETORDER(1) )
	SZ2->( DBGOTOP() )
	
	WHILE !SZ2->( EOF() )
		IF nLin >= oRelatorio:nVertRes()
			IF nLin	!=	9999
				oRelatorio:EndPage()
			ENDIF
			nLin	:=	0000
			// Inicio do relat�rio
			oRelatorio:StartPage()
			oRelatorio:Say(0030,0100,UPPER(cTitulo),oFont1)
			oRelatorio:Box(0030,1150,0130,1800)
			oRelatorio:Say(0030,1200,'Data: ' + DTOC(dDataBase),oFont6)
			oRelatorio:Say(0070,1200,'Usu�rio: ' + UsrFullName(RetCodUsr()),oFont6)
			
			// Imprime cabe�alho da tabela do relat�rio
			nLin	+=	250
			oRelatorio:Say(nLin,nPosCodigo,	UPPER("C�digo"),	oFont1)
			oRelatorio:Say(nLin,nPosTipo,	UPPER("Tipo"),		oFont1)
			oRelatorio:Say(nLin,nPosNome,	UPPER("Nome"),		oFont1)
			
			nLin	+=	45
			oRelatorio:Line(nLin,0010,nLin,oRelatorio:nHorzRes() )
		ENDIF
		
		nLin	+=	45
		//nLin	+=	500 // Para for�ar a quebra de p�gina
		oRelatorio:Say(nLin,nPosCodigo,	SZ2->Z2_CODIGO,	oFont6)
		oRelatorio:Say(nLin,nPosTipo,	SZ2->Z2_TIPO,	oFont6)
		oRelatorio:Say(nLin,nPosNome,	SZ2->Z2_NOME,	oFont6)
		
		oBrush1	:=	TBrush():New( , CLR_YELLOW )  
        oRelatorio:FillRect( {nLin, 20, nLin + 20, 40}, oBrush1 )  
        oBrush1:End()
        
		SZ2->( DBSKIP() )
	ENDDO
	
	nLin	+=	60
	oRelatorio:Line(nLin,0010,nLin,oRelatorio:nHorzRes() )
	
	nLin	+=	60
	oRelatorio:SayBitmap( nLin,100,"\system\RFBLOGO.bmp",500,172 )
	
	oRelatorio:EndPage()
Return

