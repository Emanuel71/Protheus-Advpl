#include "TOTVS.CH"

USER FUNCTION TRepo02()
	PRIVATE	cTitulo		:=	'Relat�rio de Livros'
	PRIVATE	cDescri		:=	'Emiss�o de relat�rio de Livros conforme parametros.'
	PRIVATE	oRelatorio	:=	ReportDef()

	oRelatorio:PrintDialog()
	
RETURN

STATIC FUNCTION ReportDef()
	LOCAL	oReport
	LOCAL	oSection1
	LOCAL	oBreak
	
	oReport	:=	TReport():New("TREPO002",cTitulo,'',{|oReport| PrintReport(oReport)},cDescri)
	
	oSection1	:=	TRSection():New(oReport,"Livros",{"SZ4","SZ2","SZ3"},/*aOrder*/,/*lLoadCells*/,;
					/*lLoadOrder*/,/*uTotalText*/,/*lTotalInLine*/,/*lHeaderPage*/,/*lHeaderBreak*/,;
					/*lPageBreak*/,/*lLineBreak*/,/*nLeftMargin*/,.F. )
	
	TRCell():New(oSection1,"Z4_TITULO",	"SZ4",	"T�tulo",/*cPicture*/,30,/*lPixel*/,{|| SUBSTR(SZ4->Z4_TITULO,1,30) })
	TRCell():New(oSection1,"Z2_NOME",	"SZ2",	"Nome Autor",/*cPicture*/,30,/*lPixel*/,{|| SUBSTR(SZ2->Z2_NOME,1,30) })
	TRCell():New(oSection1,"Z3_NOME",	"SZ3",	"Nome Editora",/*cPicture*/,30,/*lPixel*/,{|| SUBSTR(SZ3->Z3_NOME,1,30) })
	TRCell():New(oSection1,"Z4_EDICAO",	"SZ4",	"Edi��o")
	TRCell():New(oSection1,"Z4_ANO",	"SZ4",	"Ano")

	TRPosition():New( oSection1, "SZ2", 1, {|| SZ4->Z4_AUTOR })
	TRPosition():New( oSection1, "SZ3", 1, {|| SZ4->Z4_EDITORA })
	
	oBreak	:=	TRBreak():New(oReport, {|| SZ4->Z4_CODIGO }, {|| SZ4->Z4_CODIGO }, , 'CODIGO', .F. )
	oBreak:OnBreak( {|| oReport:PrtLeft( Replicate( '-', 120 ) ) } )
RETURN oReport

STATIC FUNCTION PrintReport(oReport)
	LOCAL	oSection1	:=	oReport:Section(1)
	
	SZ4->( DBSETORDER(1) )
	SZ4->( DBGOTOP() )
	
	oSection1:Print()

RETURN
	