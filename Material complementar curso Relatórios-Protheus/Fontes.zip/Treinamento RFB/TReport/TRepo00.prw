#include "TOTVS.CH"

USER FUNCTION TRepo01()
	PRIVATE	cTitulo		:=	'Relat�rio de Autores'
	PRIVATE	cDescri		:=	'Emiss�o de relat�rio de Autores conforme parametros.'
	PRIVATE	oRelatorio	:=	ReportDef()

	oRelatorio:PrintDialog()
	
RETURN

STATIC FUNCTION ReportDef()
	LOCAL	oReport
	LOCAL	oSection1
	
	oReport	:=	TReport():New("TREPO001",cTitulo,'',{|oReport| PrintReport(oReport)},cDescri)
	
	oSection1	:=	TRSection():New(oReport,"Autores",{"SZ2"},{'C�digo','Nome'})
	
	TRCell():New(oSection1,"Z2_CODIGO","SZ2","C�digo",,15)
	TRCell():New(oSection1,"Z2_TIPO","SZ2","Tipo",/*cPicture*/,10,/*lPixel*/,{|| TipoAut(SZ2->Z2_TIPO) })
	TRCell():New(oSection1,"Z2_NOME","SZ2","Nome",,45)

	
RETURN oReport

STATIC FUNCTION PrintReport(oReport)
	LOCAL	oSection1	:=	oReport:Section(1)
	
	SZ2->( DBSETORDER(oReport:nOrder) )
	SZ2->( DBGOTOP() )
	
	oSection1:Print()

RETURN

STATIC FUNCTION TipoAut(cTipo)
	LOCAL	cRet	:=	""
	
	aCombo	:=	RetSX3Box(GetSX3Cache('Z2_TIPO', 'X3_CBOX'),,,1)
             
    //Percorre as posi��es do combo
    FOR nAtual := 1 TO LEN(aCombo)
        //Se for a mesma chave, seta a descri��o
        IF cTipo == aCombo[nAtual][2]
            cRet := aCombo[nAtual][3]
        ENDIF
    NEXT
	
RETURN cRet
	