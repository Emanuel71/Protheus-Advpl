#include "TOTVS.CH"

USER FUNCTION TRepo04()
	PRIVATE	cTitulo		:=	'Relat�rio de Emprestimos 2'
	PRIVATE	cDescri		:=	'Emiss�o de relat�rio de Emprestimos 2 conforme parametros.'
	PRIVATE	oRelatorio	:=	ReportDef()

	oRelatorio:PrintDialog()
	
RETURN

STATIC FUNCTION ReportDef()
	LOCAL	oReport
	LOCAL	oSection1
	LOCAL	oBreak
	
	oReport	:=	TReport():New("TREPO004",cTitulo,'TREPO04',{|oReport| PrintReport(oReport)},cDescri)
	
	oSection1	:=	TRSection():New(oReport,"Empr�stimos",{"SZ6","SZ1"})
	oSection2	:=	TRSection():New(oSection1,"Itens",{"SZ7","SZ5"})
	
	TRCell():New(oSection1,"Z6_PROTOCO",	"SZ6",	"Protocolo",/*cPicture*/,/*nSize*/,/*lPixel*/,{|| QRYRPT->Z6_PROTOCO })
	TRCell():New(oSection1,"Z1_NOME",		"SZ1",	"Nome Usu�rio",/*cPicture*/,30,/*lPixel*/,{|| SUBSTR(SZ1->Z1_NOME,1,30) })
	TRCell():New(oSection1,"Z1_MUNICIP",	"SZ1",	"Cidade",/*cPicture*/,30,/*lPixel*/,{|| SUBSTR(SZ1->Z1_MUNICIP,1,30) })
	TRCell():New(oSection1,"Z1_UF",			"SZ1",	"UF",/*cPicture*/,/*nSize*/,/*lPixel*/,/*bBlock*/)
	TRCell():New(oSection1,"Z6_DATA",		"SZ6",	"Data",/*cPicture*/,/*nSize*/,/*lPixel*/,{|| DTOC(STOD(QRYRPT->Z6_DATA)) })
	
	TRCell():New(oSection2,"Z5_CODIGO",		"SZ5",	"C�digo",/*cPicture*/,/*nSize*/,/*lPixel*/,{|| QRYRPT->Z5_CODIGO })
	TRCell():New(oSection2,"EMPRESTADO",	"SZ5",	"Emprestado?",/*cPicture*/,10,/*lPixel*/,{|| IIF(QRYRPT->Z5_EMPREST == 'N','N�O','SIM') })
	TRCell():New(oSection2,"Z7_DEVPREV",	"SZ7",	"Dev Prevista",/*cPicture*/,/*nSize*/,/*lPixel*/,{|| DTOC(STOD(QRYRPT->Z7_DEVPREV)) })
	TRCell():New(oSection2,"Z7_DEVREAL",	"SZ7",	"Dev Real",/*cPicture*/,/*nSize*/,/*lPixel*/,{|| DTOC(STOD(QRYRPT->Z7_DEVREAL)) })
RETURN oReport

STATIC FUNCTION PrintReport(oReport)
	LOCAL	oSection1	:=	oReport:Section(1)
	LOCAL	oSection2	:=	oSection1:Section(1)
	LOCAL	cFiltro		:=	""
	
	PERGUNTE( oReport:uParam, .F. )
	
	cFiltro	:=	"%"
	cFiltro	+=	" AND SZ6.Z6_DATA BETWEEN '"+ DTOS(MV_PAR01) +"' AND '"+ DTOS(MV_PAR02) +"' "
	IF MV_PAR03 == 1
		cFiltro	+=	" AND SZ6.Z6_STATUS != 'D' "
	ENDIF
	cFiltro	+=	"%"
	
	IF SELECT('QRYRPT') > 0
		QRYRPT->( DBCLOSEAREA() )
	ENDIF
	
	BEGINSQL ALIAS "QRYRPT"
		SELECT	SZ6.Z6_PROTOCO,
				SZ6.Z6_USUARIO,
				SZ6.Z6_DATA,
				SZ6.Z6_STATUS,
				SZ5.Z5_CODIGO,
				SZ5.Z5_EMPREST,
				SZ7.Z7_DEVPREV,
				SZ7.Z7_DEVREAL
		FROM	%table:SZ6%	SZ6
		JOIN	%table:SZ7%	SZ7
			ON	SZ7.%notDel%
				AND SZ7.Z7_PROTOCO	=	SZ6.Z6_PROTOCO
		JOIN	%table:SZ5%	SZ5
			ON	SZ5.%notDel%
				AND SZ5.Z5_CODIGO	=	SZ7.Z7_EXEMPLA
		WHERE	SZ6.%notDel%
				%Exp:cFiltro%
	ENDSQL

	SZ1->( DBSETORDER(1) )
	QRYRPT->(DBGOTOP())
	
	
	WHILE !QRYRPT->( EOF() )
		SZ1->( DBSEEK( QRYRPT->Z6_USUARIO ) )
		oSection1:Init()
		oSection1:PrintLine()
		oSection1:Finish()
		
		cProtocolo	:=	QRYRPT->Z6_PROTOCO
		oSection2:Init()
		WHILE !QRYRPT->( EOF() ) .AND. QRYRPT->Z6_PROTOCO == cProtocolo
			
			oSection2:PrintLine()
			
			QRYRPT->( DBSKIP() )
		ENDDO
		oSection2:Finish()
		
	ENDDO
	
	
RETURN
	